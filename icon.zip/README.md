# KronchPack

Lethal Company Modpack

### Included mods:

- BepInEx-BepInExPack
- 2018-LC_API
- anormaltwig-LateCompany
- bizzlemip-BiggerLobby
- steven4547466-CommandHandler
- x753-More_Suits
- steven4547466-YoutubeBoombox
- Sligili-More_Emotes
- Drakorle-MoreItems
- tinyhoot-ShipLoot
- Suskitech-AlwaysHearActiveWalkies
- Blorb-WeatherMultipliers
- x753-Mimics
- RugbugRedfern-Skinwalkers
- AllToasters-SpectateEnemies
- HomelessGinger-MaskedEnemyOverhaul
- RickArg-Helmet_Cameras
- BatTeam-LethalFashion
